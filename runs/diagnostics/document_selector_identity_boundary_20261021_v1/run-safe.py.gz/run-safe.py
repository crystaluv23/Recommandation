from contextlib import ExitStack
import importlib.util
import json
from pathlib import Path
import socket
import sys
import unittest
from unittest.mock import patch
from stock_opportunity_agent.cases.label_store import LabelStore
from stock_opportunity_agent.data.raw_info import RawInfoStore
import run_minimal_rounds as minimal

tripwires={'network':0,'labels':0,'disk_store':0,'fullprepare':0}
def blocked(kind):
 def fail(*args,**kwargs):
  tripwires[kind]+=1
  raise AssertionError('forbidden '+kind)
 return fail
original_init=RawInfoStore.__init__
def memory_store(self,root=None,*args,**kwargs):
 if root is not None:return blocked('disk_store')()
 return original_init(self,root,*args,**kwargs)
selectors=['tests.test_document_selector_identity_boundary',
 'tests.test_data_resolution.EvidenceResolverTests.test_empty_local_selection_continues_to_authorized_acquisition',
 'tests.test_data_resolution.EvidenceResolverTests.test_document_selector_falls_through_and_rejects_invented_documents']
with ExitStack() as stack:
 for target,name,kind in ((socket,'socket','network'),(socket,'create_connection','network'),
  (LabelStore,'load','labels'),(LabelStore,'record','labels'),(LabelStore,'ground_truth','labels'),
  (minimal,'prepare','fullprepare')):
  stack.enter_context(patch.object(target,name,blocked(kind)))
 stack.enter_context(patch.object(minimal,'LABELS',Path('/forbidden-unreadable-label-store')))
 stack.enter_context(patch.object(RawInfoStore,'__init__',memory_store))
 if '--original' in sys.argv:
  import tests.test_document_selector_identity_boundary as tests
  alias='stock_opportunity_agent.data._selector_original_resolution'
  spec=importlib.util.spec_from_file_location(alias,Path(__file__).with_name('original-resolution.py'))
  old=importlib.util.module_from_spec(spec);sys.modules[alias]=old;spec.loader.exec_module(old)
  stack.enter_context(patch.object(tests,'EvidenceResolver',old.EvidenceResolver))
  stack.enter_context(patch.object(tests,'_DocumentSelectionError',old._DocumentSelectionError))
  selectors=['tests.test_document_selector_identity_boundary.DocumentSelectorIdentityBoundaryTests.test_python_equal_metadata_clone_changes_are_not_record_identity',
   'tests.test_document_selector_identity_boundary.DocumentSelectorIdentityBoundaryTests.test_selected_nested_mutation_rejects_without_poisoning_legacy_or_capture_store']
 result=unittest.TextTestRunner(verbosity=2).run(unittest.defaultTestLoader.loadTestsFromNames(selectors))
print(json.dumps({'selectors':selectors,'success':result.wasSuccessful(),'tests':result.testsRun,'tripwires':tripwires}))
sys.exit(not result.wasSuccessful())
