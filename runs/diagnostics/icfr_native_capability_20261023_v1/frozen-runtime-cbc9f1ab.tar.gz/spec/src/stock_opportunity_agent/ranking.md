# Ranking

## Status
Not started

## Purpose

Rank candidates within segments, across themes, and across the full market. Ranking turns individual research into a portfolio of watchlist priorities.

## External Interface

Expected outputs:

- Top watchlist,
- high-conviction candidates,
- action candidates,
- wait-for-pullback candidates,
- thesis-interesting-but-expensive candidates,
- likely narrative traps,
- new additions, removals, upgrades, and downgrades.

## Responsibilities

- Compare candidates inside the same segment.
- Compare final opportunity scores across themes while preserving theme context.
- Run an LLM-assisted cross-sectional comparison for closely ranked candidates when the candidate set has structured packets, score cards, and evidence on both sides.
- Detect crowding, redundancy, and sector concentration.
- Explain rank changes from prior runs.
- Require ranked high-priority outputs to carry a thesis and validation contract reference.
- Produce stable ordered outputs for reports and memory.

## Dependencies

- Consumes scanner candidates, research outputs, score cards, themes, memory, and config.
- Feeds reports, decision memory, monitoring, and review.

## Invariants

- Ranking must not collapse all context into a single unexplained number.
- Ranking should preserve why a candidate is above close alternatives.
- LLM-assisted comparison may synthesize tradeoffs, but it must not invent new evidence or override stored score cards without an explicit reason.
- Existing watchlist names should not disappear without a reason.
- A rank upgrade should distinguish score improvement, new evidence validation, catalyst proximity, and cross-sectional relative improvement.
- Cross-sectional comparisons must be as-of date aware.

## Testing

Tests should cover stable sorting, tie-breakers, category assignment, rank-change explanations, sector concentration warnings, and missing prior-run memory.
