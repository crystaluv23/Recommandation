# Stock Opportunity Agent Specs

## Status
Done

This directory defines the active module-level contracts for the future `stock_opportunity_agent` package.

The current architecture is deliberately lean: active specs stay at module level unless implementation has proved a child boundary. The data layer has active child specs because provider adapters, structured feature normalization, document retrieval, and point-in-time packet assembly already exist as separate code boundaries. Other module names below may later become single Python files or packages, but the spec tree does not force that choice before implementation proves the boundary.

Earlier pre-implementation child specs were archived under [`../../_archive/2026-05-02-preimplementation-submodule-specs/`](../../_archive/2026-05-02-preimplementation-submodule-specs/). They are historical notes, not active architecture.

## Active Intended Tree

```text
src/stock_opportunity_agent/
  artifacts
  models
  config
  data
    sources
    structured
    documents
    point_in_time
    raw_info
    resolution
  llm
    agent
  memory
    knowledge
    signals
    themes
    playbooks
  themes
  cases
  signals
  signal_library
  scanner
  research
    cold_start
    inflection_discovery
    evidence_acquisition
    ralph_loop
    information_plan
    scheme_evolution
    evolution_core
    plan_evolution
    signal_evolution
    evolution_dataset
    evolution_settings
    evolution_transport
    evolution_output_validation
    evolution_research_validation
    evolution_plan_roles
    evolution_signal_roles
    evolution_control
    evolution_runtime
    evolution_dashboard
    playbooks
  scoring
  ranking
  monitoring
  review
  meta_learning
  reports
  orchestration
```

Matching active specs:

```text
spec/src/stock_opportunity_agent/
  artifacts.md
  models.md
  config.md
  data.md
  data/sources.md
  data/structured.md
  data/documents.md
  data/point_in_time.md
  data/raw_info.md
  data/resolution.md
  data/backfill.md
  llm.md
  memory.md
  memory/knowledge.md
  memory/signals.md
  memory/themes.md
  memory/playbooks.md
  themes.md
  cases.md
  signals.md
  signal_library.md
  scanner.md
  research.md
  research/cold_start.md
  research/inflection_discovery.md
  research/evidence_acquisition.md
  research/ralph_loop.md
  research/information_plan.md
  research/scheme_evolution.md
  research/evolution_core.md
  research/plan_evolution.md
  research/signal_evolution.md
  research/evolution_dataset.md
  research/evolution_settings.md
  research/evolution_transport.md
  research/evolution_output_validation.md
  research/evolution_research_validation.md
  research/evolution_plan_roles.md
  research/evolution_signal_roles.md
  research/evolution_control.md
  research/evolution_runtime.md
  research/evolution_dashboard.md
  research/playbooks.md
  scoring.md
  ranking.md
  monitoring.md
  review.md
  meta_learning.md
  reports.md
  orchestration.md
```

## Design Coverage

The active module set reflects the system-design discussion without turning every future helper into an entity:

- The thesis-centered loop, expectation-gap research, watchlist output, validation contracts, and recommendation/trading separation live in [`vision.md`](../../vision.md) and [`architecture.md`](../../architecture.md).
- Point-in-time data, structured data as backbone, document retrieval, and the
  append-only adaptive research fact store live in [`data.md`](data.md).
- Local long-term memory for companies, theses, signals, cases, decisions, reviews, current universe state, themes, research playbooks, segments, experiments, and preferences lives in [`memory.md`](memory.md).
- Historical winners, controls, failures, and blind analysis packets live in [`cases.md`](cases.md).
- Theme discovery, industry-chain transmission, segment stage, and timing live in [`themes.md`](themes.md).
- Existing packet measurement rules live in [`signals.md`](signals.md); the
  versioned deterministic/LLM Signal Registry used by self-evolution lives in
  [`signal_library.md`](signal_library.md).
- Reusable provider discovery and the domain-tool-only Generic Agent harness
  live in [`llm.md`](llm.md).
- Non-LLM coarse screening, current-state-aware rerun selection, and anomaly-driven candidate surfacing before expensive research live in [`scanner.md`](scanner.md).
- LLM research, skeptic passes, valuation critique, evidence-for/evidence-against, cold-start playbook synthesis, validation-contract drafting, and structured thesis output live in [`research.md`](research.md).
- Theme scores, Segment Timing, Company Rocket Score, Launch Probability, Upside Potential, and risk adjustment live in [`scoring.md`](scoring.md).
- Segment-level and market-level comparison live in [`ranking.md`](ranking.md).
- Catalyst triggers, validation-contract checks, and watchlist state transitions live in [`monitoring.md`](monitoring.md).
- Outcome tracking, earnings validation, error labeling, thesis validation, and signal attribution live in [`review.md`](review.md).
- Meta-learning, experiments, version comparison, and controlled change proposals live in [`meta_learning.md`](meta_learning.md).
- Human-facing watchlists, cards, reviews, and audit bundles live in [`reports.md`](reports.md).
- Cold-start, daily, weekly, monthly, quarterly, and manual workflows live in [`orchestration.md`](orchestration.md).

## Occam Boundary Rule

Add a child spec only when:

- another module needs a stable interface from that submodule,
- the parent spec grows beyond about 150 lines and has separable concerns, or
- implementation has already created a source package whose internal modules need different invariants or tests.

Until then, keep the boundary inside the parent spec. This prevents the design from mistaking a plausible future helper for a necessary system entity.
