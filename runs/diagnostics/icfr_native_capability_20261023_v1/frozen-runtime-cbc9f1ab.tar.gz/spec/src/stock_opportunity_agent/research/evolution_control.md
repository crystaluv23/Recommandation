# Evolution Control

New Fast bootstrap and Slow-history manifests carry `knowledge_observations`
derived from complete pointer-reachable records and authorized transitive imports.
Rows preserve their original opaque case/scope and event identities. Old manifests
without this optional array remain immutable and authorize no inferred Experience
adoption. Pre-contract definition materialization does not expose imported
performance; only the published hash-bound run contract grants read authority.

New committed-history/bootstrap manifests may carry immutable
`prediction_observations` built from their authorized committed Fast records.
Imports verify observation content identity and retain origin contract/record/
trajectory provenance. Local Fast history and inherited observations compose
without changing historical meta, scores, source pointers or manifests. Legacy
imports without observations grant no implicit access to another workspace.

Frozen contract loading preserves the JSON representation of an accepted numeric
cost ceiling (integer or float). Loading and re-freezing must reproduce its exact
canonical hash without rewriting the original file. Booleans, nonnumbers and
nonfinite/nonpositive values still fail the existing constructor validation.

## V8 finite slow-only control

The run contract supports `fast_then_slow`, one-cycle `slow_bootstrap`, and
finite `slow_only`. Slow-only fixes zero Fast rounds, positive cumulative
`max_slow_cycles`, `min_new_signals_per_cycle`, one committed-only source history
manifest, and bounded role budgets. `--max-cycles` may reduce work in one CLI
invocation but cannot enlarge the contract total across resumes.

A v8 `fast_then_slow` contract may also freeze one committed-only source
history manifest: this is dual-loop continuation, requested by passing an
explicit `--cycle-mode fast_then_slow` together with `--slow-history-from`.
Fast-round targets stay positive, and the import follows the identical
succession rules below (namespaces, exact Registry, provisional residents,
pooled evaluation, chain continuity on resume). `--slow-history-from` without
an explicit mode still infers `slow_only`, and `slow_bootstrap` remains
mutually exclusive with a history manifest.

History import preserves namespaced pointer-reachable history: the immediate
source contributes one namespace, and that source's own imported namespaces
are carried forward unchanged so multi-hop successor chains keep the full
namespaced history that resident enumeration and reflection footprints read.
Exact Registry, usage, experiment, and memory hashes are preserved. It never
imports staged or rejected work as completed history. Provisional residents are the one
exception to dropping staged work: the history manifest carries the source's
`signals_candidates` tree (excluding the `.rejected` archive) so provisional
residents and their pooled evaluation history survive workspace succession,
and the successor enumerates provisional attempts from the namespaced
imported cycle artifacts plus its own committed cycles — pooled three-zone
accumulation therefore continues across workspace boundaries instead of
resetting to zero in every successor. The initial seed hash is checked once;
subsequent Registry continuity comes from committed cycle state so legitimate
promotion does not conflict with the frozen seed.
Learning-event continuity is transitive across execution modes. In addition to
events owned by Fast rounds at or below the source Fast pointer, a Slow-history
manifest carries the exact events already imported through its source's frozen
`slow_bootstrap` or `slow_history` manifest. Those inherited events must exist
byte-for-byte in the source Registry before they may be re-exported. Events found
only in mutable Registry ledgers, and not reachable from either the committed Fast
pointer or a contract-bound import manifest, remain excluded.
Imports preserve exact v1/v2 event identity and source metadata. A new committed
Fast bootstrap derives v2 identities from its hash-verified source records;
existing frozen import manifests remain unchanged and resume with their original
events. No import promotes repeated case/input use into independent evidence.
Contract-bound learning import parsing is shared with Signal tracking consumers,
including `fast_then_slow` contracts carrying a history manifest. Export and
consumption must agree on exact inherited event identities. Source round numbers
never serve as the successor's local Fast cutoff.
An unfinished higher-numbered active cycle does not invalidate the committed
prefix: its staged files are ignored. Import is allowed only when the live
Registry still equals the version/hash recorded at the committed pointer, the
active cycle id is strictly after that pointer, and every artifact required for
each committed cycle exists. A post-transition/pre-pointer Registry mismatch or
an incomplete committed cycle fails closed because the committed snapshot
cannot then be reconstructed safely. Within a running slow_only workspace the
live Registry may advance past the imported history manifest: each committed
cycle records its exact input and output Registry identity, and resume accepts
a live Registry that equals the committed chain's last output (a promotion
committed by an own cycle), still rejecting any drift the chain does not
explain. Each CLI invocation also bounds every cycle's wall time with a
watchdog: a silent stall (CPU-bound explosion or wedged I/O) becomes the
retryable channel — exit 75, auto-resume, cycle restart from the committed
boundary with request-cache replay — instead of an unbounded hang.

## Purpose

Own frozen run contracts, recovery/preflight checks, role composition, and the
bounded Fast/Slow cycle entry point.

## Invariants

- Only committed workspace pointers define progress.
- Runtime verification binds code, dataset, Signal Registry, and model
  identities before execution.
- Readiness, external authorization, transmitted work, and committed state are
  represented separately.
- This module composes lower layers and contains no role-specific parser.

Every newly frozen executable contract records `max_parallel_plans`; the CLI
defaults it to 2 and validates it as a positive integer no greater than the
candidate count. Runtime passes values above 1 to a production evaluator
factory that creates worker-local mutable role/resolver/client state. Legacy
contracts without the field execute with 1, preserving the proven V130
sequential composition. The workspace lock still has one coordinator, and all
worker progress is funneled through a lock-protected append so event order and
sequence ids remain valid.


The production evidence resolver connects configured Finnhub news after Alpha
Vantage, matching the existing news capability catalog. The fallback uses the
same managed transport, cache, ledger and frozen authorization ceilings. A new
code checkpoint requires a successor contract; an interrupted workspace is not
retroactively run against changed adapter wiring.


## Imported committed Signal tracking

Historical Registry identity is a definition/provenance read, not a fresh
execution freeze. Slow-history export/materialization and both rejected-gap and
committed-Fast bootstrap source checks reconstruct the current stable definitions
and skills in their native order with `snapshot_from_refs`, then compare the
version/hash with the existing committed pointer or explicitly frozen target
authority. An empty Registry or a changed stable definition/version still fails.
Registry versions in headers, manifests, committed Registry pointers and frozen
snapshot authorities must be positive JSON integers; bool, float or string
coercion cannot establish identity. Reject malformed authorities before target
materialization or event writes, including manifest validation and replay.
They must not execute historical fixtures under a later runtime merely to read
committed history. Source fixture/spec/skill bytes and their manifest bindings
remain unchanged; no import repairs, upgrades or silently enables a version.

This definition-only read supplies no learned profile or present-day capability
certificate. Learning-event cutoffs, knowledge provenance, source contracts,
namespaced artifacts and imported-event identity retain their separate existing
validation. Fresh execution, candidate admission and promotion continue to use
the normal capability-audited `freeze()`; importing historical definitions cannot
make an incompatible fixture executable or bypass current issuer/PIT gates.

Hash-verified committed Slow-history and Fast-bootstrap learning events use the
same tracking bridge as local round commits. It derives only the purposes declared
by exact version metadata, preserves imported event identities, and never imports
staged/unbound rows as target effectiveness.

## Diagnostic committed-Fast succession

`scripts/run_minimal_rounds.py --slow-bootstrap-from SOURCE` extends the existing
diagnostic entry point through the production committed-Fast manifest builder,
validator and derivative bridge. It reuses SOURCE's hash-verified diagnostic
case/label/source manifest exactly; it does not resample or rerun its committed
Fast cases. Only stable definitions are copied, excluding stats, learning ledgers,
derived profiles and candidates. The new input manifest binds source input hash,
bootstrap manifest hash and ordered initial definition refs; Registry's exact-ref
definition snapshot must reproduce the initial version/hash even after a valid
publication on recovery. The new contract has zero Fast rounds, one Slow cycle,
and existing finite attempt/token/cost/data limits. Source pointers are not copied.
Imported meta uses the reserved negative range; imported events keep source ids.
The entry point uses the existing workspace lock, exact requests, stage validators,
technical admission and atomic cycle commit. A changed source/mode/seed or partially
prepared target cannot silently overwrite a frozen target. Tests distinguish this
entry wiring from authored research quality; live artifacts remain required.

`--slow-history-from SOURCE` uses the same diagnostic entry for an ordinary
Fast→Slow successor after SOURCE has committed a Slow cycle. It preserves the
verified diagnostic case/label/source manifest without resampling, imports the
production committed-only history manifest and its exact published Registry,
namespaced artifacts, candidates and authorized learning events, and freezes a
`fast_then_slow` contract with one local Fast round and one Slow cycle. The input
binds the source input hash, history hash and initial ordered version refs. Seed,
bootstrap and history options are mutually exclusive. A history source's old
bootstrap/mode fields do not become the successor's mode. Imported Fast-context
meta uses the shared negative numbering and stays outside blind prediction.
Runtime source validation and committed Registry-chain validation use the
production functions; neither imported source pointers nor a diagnostic staged
candidate advance the successor's local pointers. Applying history again after
own publication is forbidden; staged-result recovery remains authoritative.

## Frozen reuse observations

Bootstrap/history manifests may add `knowledge_reuse_observations`, exported
read-only from committed source records/cycles plus authorized transitive imports.
The shared reader verifies event identity and frozen manifest binding. Legacy
manifests without this field retain unknown reuse, with no fabricated events.

## Local backend and parallel Jev preflight

A contract whose judge backend is independent-subagent cannot enable the parallel
Jev Decisions path with provider-derived choice distributions. Builder, frozen-contract parsing and runtime preflight
reject this capability conflict before constructing a remote provider. Runtime
role composition also checks the actual judge caller registration/exchange and
frozen judge identity, and rejects
an explicit `allow_external=False` before constructing OpenRouter Jev. Missing
legacy fake-caller permission metadata is not guessed false. Remote-only mode
with explicit external permission retains its original decisions and scoring;
flag false retains native StructuredRoleClient routing and four-way Predictor.
No local token logprobs or provider identity are invented.

A local proposer/mining/update with a remote judge remains a supported hybrid
when external execution is explicitly permitted; those roles do not own the
Jev closed-choice capability. This does not authorize remote calls in the
current all-local run.
